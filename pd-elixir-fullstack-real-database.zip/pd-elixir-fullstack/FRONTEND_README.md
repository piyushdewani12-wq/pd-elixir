# PD Elixir — E-commerce Starter

A polished front-end e-commerce prototype for PD Elixir, a Pakistan-focused perfume brand.

## Included
- Premium light/dark luxury theme
- 100 seeded products: Men, Women, Unisex
- 50ml / 100ml product presentation
- Search, category filters, sorting
- Product detail modal with top/middle/base notes
- Wishlist and cart using localStorage
- Buy Now + checkout UI
- COD + online-payment option UI
- Customer signup/login demo using localStorage
- Order placement + basic order tracking demo
- Rs. 200 shipping, free above Rs. 3,000
- Responsive mobile layout

## Production security
This is a browser-based prototype. Do NOT use the demo localStorage authentication for a real store. Before launch, move authentication, passwords, orders, inventory and payment verification to a secure server/database, hash passwords, use HTTPS, secure cookies/sessions, role-based admin access, server-side validation, rate limiting and a real Pakistan payment gateway merchant integration. Never store raw card details.
