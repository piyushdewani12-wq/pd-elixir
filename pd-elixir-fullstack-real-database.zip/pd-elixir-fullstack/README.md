# PD Elixir — Real Database E-commerce Starter

This is a real local full-stack store, not only static HTML.

## Run on Windows
1. Install Node.js 20+ from nodejs.org.
2. Extract this ZIP.
3. Open the extracted folder.
4. In that folder, open PowerShell/Command Prompt.
5. Run `npm install`
6. Run `npm start`
7. Open `http://localhost:3000`

## Database
A real SQLite database named `pd-elixir.db` is created automatically. It stores customers, hashed passwords, products, stock, orders and order items.

## Admin
Development admin:
- Email: admin@pdelixir.com
- Password: PDElixir@123

Change these before production using ADMIN_EMAIL, ADMIN_PASSWORD and JWT_SECRET environment variables.

## Payment
COD is functional. The Online Payment option is a secure integration point, but live payment capture cannot be honestly enabled without your merchant account credentials and the gateway's server-side API/webhook configuration. Do not put payment secrets in browser JavaScript.

## Production
For launch, use HTTPS, strong secrets, PostgreSQL/managed DB, secure cookies, rate limiting, input validation, backups and a verified Pakistan payment gateway. The current app is the working local database version so you can test the whole store before deployment.
